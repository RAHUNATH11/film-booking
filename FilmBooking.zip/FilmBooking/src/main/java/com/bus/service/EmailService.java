package com.bus.service;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

public class EmailService {

    private JavaMailSender javaMailSender;

    public EmailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    public void sendBookingConfirmationEmail(String recipientEmail) throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        // Set sender and recipient
        helper.setFrom("rahunath11@gmail.com");
        helper.setTo(recipientEmail);

        // Set email subject
        helper.setSubject("Booking Confirmation");

        // Set email content
        String content = "<html><body><h3>Booking Confirmation</h3><p>Your booking has been confirmed.</p></body></html>";
        helper.setText(content, true);

        // Send email
        javaMailSender.send(message);
    }
}
